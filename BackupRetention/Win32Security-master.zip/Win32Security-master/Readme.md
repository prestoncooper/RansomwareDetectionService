**Win32Security**

This is a fork of a the Win32Security library written by 
Renaud Paquay, who I believe is a Microsoft employee. I have modified to include some service related access masks.

**Description**
	  
A C# library containing wrapper classes for ACL, ACE, Security descriptors, Security Attributes, Access tokens, etc. 

The original library was located here:

http://www.gotdotnet.com/Community/UserSamples/Details.aspx?SampleGuid=e6098575-dda0-48b8-9abf-e0705af065d9